package com.example.project2_part3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ManageSystemActivity extends AppCompatActivity {
    private EditText usernameText, passwordText, titleText, authorText, priceText;
    private Button signIn, yes, no, addBook;
    private TextView transactionText;
    private RentalSystemDatabase db;
    private int numOfAttempts = 2;
    private boolean validSignIn = false;
    private boolean addingBook = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system);

        usernameText = findViewById(R.id.usernameEditText);
        passwordText = findViewById(R.id.passwordEditText);
        titleText = findViewById(R.id.titleEditText);
        authorText = findViewById(R.id.authorEditText);
        priceText = findViewById(R.id.priceEditText);
        signIn = findViewById(R.id.signInButton);
        yes = findViewById(R.id.yesButton);
        no = findViewById(R.id.noButton);
        addBook = findViewById(R.id.addBookButton);

        signIn.setOnClickListener (new View.OnClickListener() {
            @Override
            /*public void onClick(View v) {
                String username = usernameText.getText().toString();
                String password = passwordText.getText().toString();
                if (!usernameText.getText().toString().equals("") && !passwordText.getText().toString().equals("")) {
                    String toastMsg;
                    db = RentalSystemDatabase.getDatabase(ManageSystemActivity.this);
                    List<User> list = db.getRentalSystemDOA().getUserByUsername("Admin2");
                    if (list.size() == 1) {
                        User admin = list.get(0);
                        if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                            authenticated = true;
                            toastMsg = "Sign in successful! Now displaying all transactions.";
                            Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                            displayTransactions();
                        }
                        else {
                            numOfAttempts();
                        }
                    }
                    else {
                        toastMsg = "Error! Please contact system administrator!";
                        Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                        menu();
                    }
                }
                else {
                    numOfAttempts();
                }
            }*/
            public void onClick(View v) {
                String username = usernameText.getText().toString();
                String password = passwordText.getText().toString();
                String toastMsg;
                if (!usernameText.getText().toString().equals("") &&
                        (!passwordText.getText().toString().equals(""))) {
                    if (authenticateAdmin(username, password)) {
                        validSignIn = true;
                        toastMsg = "Sign in successful!";
                        Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
                        displayTransactions();
                    }
                }
            }
        });

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String toastMsg;
                if (validSignIn == true) {
                    addingBook = true;
                    toastMsg = "Please enter new book information...";
                    Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
                else {
                    toastMsg = "Please sign in before continuing!";
                    Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validSignIn == true) {
                   menu();
                }
                else {
                    String toastMsg = "Please sign in before continuing!";
                    Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });

        addBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validSignIn == true && addingBook == true) {
                    String title = titleText.getText().toString();
                    String author = authorText.getText().toString();
                    String priceStr = priceText.getText().toString();
                    double price = Double.parseDouble(priceStr);
                    String toastMsg;
                    if (!titleText.getText().toString().equals("") && !authorText.getText().toString().equals("") &&
                        !priceText.getText().toString().equals("")) {
                        if (addBook(title, author, price)) {
                            toastMsg = "Book successfully added to database!";
                            Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                            logTransaction(title, author, price);
                            menu();
                        }
                        else {
                            toastMsg = "Book title is already in use!";
                            Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                            menu();
                        }
                    }
                    else {
                        toastMsg = "The book information is invalid!";
                        Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                        menu();
                    }
                }
                else {
                    String toastMsg = "Please sign in and/or answer the prompt before continuing!";
                    Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public boolean authenticateAdmin(String username, String password) {
        String toastMsg;
        db = RentalSystemDatabase.getDatabase(ManageSystemActivity.this);
        List<User> list = db.getRentalSystemDOA().getUserByUsername("Admin2");
        if (list.size() == 1) {
            User user = list.get(0);
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
            else { numOfAttempts(); }
        }
        else { numOfAttempts(); }
        return false;
    }

    public void displayTransactions() {
        transactionText = findViewById(R.id.transactionTextView);
        db = RentalSystemDatabase.getDatabase(this);
        List<Transaction_> transactionList = db.getRentalSystemDOA().getAllTransactions();
        String bookListText = "========== Transaction List ==========";
        for (Transaction_ transaction : transactionList) {
            bookListText += "\n" + transaction.getId() + ", "
                    + transaction.getType() + ", "
                    + transaction.getMessage();
        }
        Toast.makeText(ManageSystemActivity.this, bookListText, Toast.LENGTH_LONG).show();
    }

    public boolean addBook(String title, String author, double price) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = new Date();
        db = RentalSystemDatabase.getDatabase(this);
        List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(title);
        if (bookList.size() == 0) {
            Book newBook = new Book(title, author, price);
            db.getRentalSystemDOA().insert(newBook);
            return true;
        }
        else { return false; }
    }

    public void logTransaction(String title, String author, double price) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = new Date();
        String message = title + ", by " + author + " added to book database: " + formatter.format(date);
        Transaction_ transaction = new Transaction_("New book", message);
        db.getRentalSystemDOA().insert(transaction);
    }

    public void numOfAttempts() {
        String toastMsg;
        numOfAttempts--;
        toastMsg = "\"Username and/or password requirements not met!";
        Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();

        if (numOfAttempts == 0) {
            toastMsg = "Too many failed attempts! Returning to main menu";
            Toast.makeText(ManageSystemActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
    }

    public void menu() {
        Intent main = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main);
    }
}
