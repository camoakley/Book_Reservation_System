package com.example.project2_part3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {
    private Button createAccount, placeHold, cancelHold, manageSystem;
    private RentalSystemDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        createAccount = findViewById(R.id.createButton);
        placeHold = findViewById(R.id.placeButton);
        cancelHold = findViewById(R.id.cancelButton);
        manageSystem = findViewById(R.id.manageButton);

        createAccount.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createAccount = new Intent(getApplicationContext(), CreateAccountActivity.class);
                startActivity(createAccount);
            }
        });

        placeHold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent placeHold = new Intent(getApplicationContext(), PlaceHoldActivity.class);
                startActivity(placeHold);
            }
        });

        cancelHold.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cancelHold = new Intent(getApplicationContext(), CancelHoldActivity.class);
                startActivity(cancelHold);
            }
        });

        manageSystem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent manageSystem = new Intent(getApplicationContext(), ManageSystemActivity.class);
                startActivity(manageSystem);
            }
        });

    appInitialization();
}

    private void appInitialization() {
        db = RentalSystemDatabase.getDatabase(this);

        List<User> userList = db.getRentalSystemDOA().getAllUsers();
        if (userList.size() <= 0) {
            User[] defaultUser = new User[4];
            defaultUser[0] = new User("alice5", "csumb100");
            defaultUser[1] = new User("Brian7", "123abc");
            defaultUser[2] = new User("chris12", "CHRIS12");
            defaultUser[3] = new User("Admin2", "Admin2");
            db.getRentalSystemDOA().insert(defaultUser);
        }

        List<Book> bookList = db.getRentalSystemDOA().getAllBooks();
        if (bookList.size() <= 0) {
            Book[] defaultBook = new Book[3];
            defaultBook[0] = new Book("Hot Java", "S. Narayanan", 1.50);
            defaultBook[1] = new Book("Fun Java", "Y. Byun", 2.00);
            defaultBook[2] = new Book("Algorithm for Java","K. Alice", 2.25);
            db.getRentalSystemDOA().insert(defaultBook);
        }

        /*SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        List<Transaction_> transactionList = db.getRentalSystemDOA().getAllTransactions();
        if (transactionList.size() <= 0) {
            Transaction_[] defaultTransaction = new Transaction_[7];
            defaultTransaction[0] = new Transaction_("New account", "alice5 added to user database: " + formatter.format(date));
            defaultTransaction[1] = new Transaction_("New account", "Brian7 added to user database: " + formatter.format(date));
            defaultTransaction[2] = new Transaction_("New account", "chris12 added to user database: " + formatter.format(date));
            defaultTransaction[3] = new Transaction_("New account", "Admin added to user database: " + formatter.format(date));
            defaultTransaction[4] = new Transaction_("New book", "Hot Java, by S. Narayanan added to book database: " + formatter.format(date));
            defaultTransaction[5] = new Transaction_("New book", "Fun Java, by Y. Byun added to book database: " + formatter.format(date));
            defaultTransaction[6] = new Transaction_("New book", "Algorithm for Java, by K. Alice added to book database: " + formatter.format(date));
            db.getRentalSystemDOA().insert(defaultTransaction);
        }*/
    }
}
