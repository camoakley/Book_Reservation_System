package com.example.project2_part3;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Reservation")
public class Reservation {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private int pickupDay, returnDay;
    private String username, bookTitle, pickupDate, returnDate;
    private boolean active = true;

    public Reservation() {
        // default constructor - no initialization.
    }

    public Reservation(String username, String bookTitle, String pickupDate, int pickupDay,
                       String returnDate, int returnDay) {
        this.username = username;
        this.bookTitle = bookTitle;
        this.pickupDate = pickupDate;
        this.pickupDay = pickupDay;
        this.returnDate = returnDate;
        this.returnDay = returnDay;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getBookTitle() { return bookTitle; }

    public String getPickupDate() { return pickupDate; }

    public int getPickupDay() { return pickupDay; }

    public String getReturnDate() { return returnDate; }

    public int getReturnDay() { return returnDay; }

    public boolean getActive() { return active; }

    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    public void setPickupDay(int pickupDay) {
        this.pickupDay = pickupDay;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public void setReturnDay(int returnDay) {
        this.returnDay = returnDay;
    }

    public void setActive(boolean active) { this.active = active; }
}