package com.example.project2_part3;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
//import androidx.room.TypeConverters;

@Database(entities = {User.class, Book.class, Transaction_.class, Reservation.class}, version = 1)
//@TypeConverters({Converters.class})
public abstract class RentalSystemDatabase extends RoomDatabase {
    public abstract RentalSystemDOA getRentalSystemDOA();

    private volatile static RentalSystemDatabase dbInstance;

    public static RentalSystemDatabase getDatabase(Context context) {
        if(dbInstance == null) {
            synchronized (User.class) {
                if (dbInstance == null) {
                    dbInstance = Room.databaseBuilder(context.getApplicationContext(),
                                    RentalSystemDatabase.class,
                                    "RentalSystem.DB").
                            allowMainThreadQueries().
                            build();
                }
            }
        }
        return dbInstance;
    }
}

