package com.example.project2_part3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.List;

public class CreateAccountActivity extends AppCompatActivity {
    private EditText usernameText, passwordText;
    private Button createAccount;
    private RentalSystemDatabase db;
    private int numOfAttempts = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameText = findViewById(R.id.usernameEditText);
        passwordText = findViewById(R.id.passwordEditText);
        createAccount = findViewById(R.id.createButton);

        createAccount.setOnClickListener (new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameText.getText().toString();
                String password = passwordText.getText().toString();
                String toastMsg;
                if (!usernameText.getText().toString().equals("") && !passwordText.getText().toString().equals("")) {
                    if (username.length() < 11 && password.length() < 11 && username.length() > 3 && password.length() > 3) {
                        if (textCheck(username) && textCheck(password)) {
                            if (addUser(username, password)) {
                                toastMsg = "Account successfully created!";
                                Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                                logTransaction(username);
                                menu();
                            }
                            else {
                                numOfAttempts--;
                                if (numOfAttempts == 0) {
                                    toastMsg = "Username is already in use!\nToo many failed attempts! Returning to main menu...";
                                    Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                                    menu();
                                }
                                else {
                                    toastMsg = "Username is already in use! Please try again...";
                                    Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                        else {
                            //toastMsg = "Field requirements not met!";
                             /*toastMsg = "Username and/or password requirements not met!";
                             Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();*/
                            numOfAttempts();
                        }
                    }
                    else {
                        //toastMsg = "Field parameters not met!";
                        /*toastMsg = "Username and/or password requirements not met!";
                        Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();*/
                        numOfAttempts();
                    }
                }
                else {
                    //toastMsg = "Incorrect parameters!";
                    /*toastMsg = "Username and/or password requirements not met!";
                    Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();*/
                    numOfAttempts();
                }
            }
        });
    }

    public boolean textCheck(String text) {
            int countDigit = 0, countLetter = 0, countSpecial = 0;
            for (int i = 0; i < text.length(); i++) {
                if (Character.isLetter(text.charAt(i))) {
                    countLetter++;
                }
                else if (Character.isDigit(text.charAt(i))) {
                    countDigit++;
                }
                else if (!(Character.isLetter(text.charAt(i))) &&
                        !(Character.isDigit(text.charAt(i)))) {
                    countSpecial++;
                }
            }
        return countLetter >= 3 && countDigit >= 1 && countSpecial == 0;
    }

    public boolean addUser(String username, String password) {
        db = RentalSystemDatabase.getDatabase(this);
        List<User> userList = db.getRentalSystemDOA().getUserByUsername(username);
        if (userList.size() == 0) {
            User newUser = new User(username, password);
            db.getRentalSystemDOA().insert(newUser);
            return true;
        }
        else { return false; }
    }

    public void logTransaction(String username) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        String message = username + "  added to user database: " + formatter.format(date);
        Transaction_ transaction = new Transaction_("New account", message);
        db.getRentalSystemDOA().insert(transaction);
    }

    public void numOfAttempts() {
        String toastMsg;
        numOfAttempts--;
        toastMsg = "Username and/or password requirements not met!";
        Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();

        if (numOfAttempts == 0) {
            toastMsg = "Too many failed attempts! Returning to main menu...";
            Toast.makeText(CreateAccountActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
    }

    public void menu() {
        Intent main = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main);
    }
}
