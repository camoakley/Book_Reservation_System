package com.example.project2_part3;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface RentalSystemDOA {

    // USERS
    @Insert
    void insert(User... users);

    @Query("SELECT * FROM Book WHERE author = :name  ORDER BY title ASC")
    List<Book> searchByName(String name);

    @Query("SELECT * FROM User WHERE username = :username")
    List<User> getUserByUsername(String username);

    @Query("SELECT * FROM User")
    List<User> getAllUsers();


    //BOOKS
    @Insert
    void insert(Book... books);

    @Update
    void update(Book... books);

    @Query("SELECT * FROM Book")
    List<Book> getAllBooks();

    @Query("SELECT * FROM Book WHERE title = :title")
    List<Book> getBookByTitle(String title);


    // TRANSACTIONS
    @Insert
    void insert(Transaction_... transactions);

    @Query("SELECT * FROM Transaction_")
    List<Transaction_> getAllTransactions();


    // RESERVATION
    @Insert
    void insert(Reservation... reservations);

    @Update
    void update(Reservation... reservations);

    @Query("SELECT * FROM Reservation WHERE username = :username AND active = :active")
    List<Reservation> getHeldBookByUserAndActive(String username, boolean active);

    @Query("SELECT * FROM Reservation WHERE username = :username AND bookTitle = :bookTitle")
    List<Reservation> getHeldBookByUserAndTitle(String username, String bookTitle);
}

