package com.example.project2_part3;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PlaceHoldActivity extends AppCompatActivity {
    private EditText pickupDateText, returnDateText, bookTitleText, usernameText, passwordText;
    private Button confirmButton, placeHoldButton, selectBookButton;
    private RentalSystemDatabase db;
    private boolean validDates = false;
    private boolean validBook = false;
    private int numOfAttempts = 2, pickupDay = 0, returnDay = 0;
    private String pickupDate = "NA", returnDate = "NA", bookTitle = "NA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_hold);

        pickupDateText = findViewById(R.id.pickupDateEditText);
        returnDateText = findViewById(R.id.returnDateEditText);
        bookTitleText = findViewById(R.id.bookTitleEditText);
        usernameText = findViewById(R.id.usernameEditText);
        passwordText = findViewById(R.id.passwordEditText);
        confirmButton = findViewById(R.id.confirmButton);
        selectBookButton = findViewById(R.id.selectBookButton);
        placeHoldButton = findViewById(R.id.placeHoldButton);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!pickupDateText.getText().toString().equals("")) {
                    pickupDate = pickupDateText.getText().toString();
                    String[] pickupAry = pickupDate.split("/",3);
                    returnDate = returnDateText.getText().toString();
                    String[] returnAry = returnDate.split("/",3);
                    pickupDay = Integer.parseInt(pickupAry[1]);
                    returnDay = Integer.parseInt(returnAry[1]);

                    if ((pickupDay + 6) >= returnDay) {
                        validDates = true;
                        getBooksByDate(pickupAry, returnAry);
                    }
                    else {
                        String toastMsg = "Error! Max rental time is 7 days!";
                        Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                        menu();
                    }
                }
                else {
                    String toastMsg = "Please enter valid dates!";
                    Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });

        selectBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validDates == true) {
                    if (!bookTitleText.getText().toString().equals("")) {
                        bookTitle = bookTitleText.getText().toString();
                        if ((pickupDay + 6) >= returnDay) {
                            selectBook(bookTitle);
                        }
                        else {
                            String toastMsg = "Max rental time is 7 days! Please adjust dates...";
                            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                        }
                    }
                    else {
                        String toastMsg = "Please enter a book name!";
                        Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                    }
                }
                else {
                    String toastMsg = "Please enter valid dates before continuing!";
                    Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });

        placeHoldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validDates == true && validBook == true) {
                    String username = usernameText.getText().toString();
                    String password = passwordText.getText().toString();
                    if (!usernameText.getText().toString().equals("") &&
                            (!passwordText.getText().toString().equals(""))) {
                        if (authenticateUser(username, password)) {
                            List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(bookTitle);
                            placeHold(username, bookTitle);
                            logTransaction(username, bookTitle, bookList.get(0).getPrice());
                            menu();
                        }
                    }
                }
                else {
                    String toastMsg = "Please enter valid dates and/or pick a book before continuing!";
                    Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void getBooksByDate(String[] pickupAry, String[] returnAry) {
        db = RentalSystemDatabase.getDatabase(PlaceHoldActivity.this);
        List<Book> bookList = db.getRentalSystemDOA().getAllBooks();
        List<Book> availableBooks = new ArrayList<Book>();

        for(Book book : bookList) {
            String availability = book.getAvailability();
            int count = 0;
            for (int i = pickupDay; i <= returnDay; i++) {
                if (availability.charAt(i) == '-')
                    count++;
            }
            if (count == 0)
                availableBooks.add(book);
        }

        if (availableBooks.size() == 0) {
            String toastMsg = "No books are available for the specified dates!";
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
        else {

            String bookListText = "========== Available Book(s) ==========";
            for (Book book : availableBooks) {
                double price = book.getPrice() * ((1 + returnDay) - pickupDay);
                bookListText += "\n" + book.getId() + ", Title: "
                        + book.getTitle() + ", Author: "
                        + book.getAuthor() + ", Price: $"
                        + String.format("%,.2f", price);
            }
            String toastMsg;
            Toast.makeText(PlaceHoldActivity.this, bookListText, Toast.LENGTH_LONG).show();
        }
    }

    public void selectBook(String title) {
        db = RentalSystemDatabase.getDatabase(PlaceHoldActivity.this);
        List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(title);
        int count = 0;
        if (bookList.size() == 1) {
            validBook = true;
            String availability = bookList.get(0).getAvailability();
            for (int i = pickupDay; i <= returnDay; i++) {
                if (availability.charAt(i) == '-') {
                    count++;
                }
            }
            if (count == 0) {
                validBook = true;
                String toastMsg = "Book match found! Please sign in to place a hold on this book.";
                Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            }
            else {
                String toastMsg = "The book is not available for the specified dates! Please try again...";
                Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            }
        }
        else {
            String toastMsg = "No matches found! Please enter a valid book title...";
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
        }
    }

    public void placeHold(String username, String title) {
        db = RentalSystemDatabase.getDatabase(PlaceHoldActivity.this);
        List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(title);
        String toastMsg;
        if (bookList.size() == 1) {
            validBook = true;
            String availability = bookList.get(0).getAvailability();
            for(int i = pickupDay; i <= returnDay; i++) {
                availability = availability.substring(0, i) + "-" + availability.substring(i + 1);
            }

            bookList.get(0).setAvailability(availability);
            db.getRentalSystemDOA().update(bookList.get(0));

            Reservation reservation = new Reservation(username, bookList.get(0).getTitle(), pickupDate,
                    pickupDay, returnDate, returnDay);
            db.getRentalSystemDOA().insert(reservation);

            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            Date date = new Date();
            double price = bookList.get(0).getPrice() * ((returnDay + 1) - pickupDay);

            toastMsg = username + ", renting " + title+ " from " + pickupDate + " - " +
                    returnDate + " for $" + String.format("%,.2f", price) + ": " +  formatter.format(date);
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
        }
        else {
            toastMsg = "No matches found! Please enter a valid book title...";
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
        }
    }

    public boolean authenticateUser(String username, String password) {
        String toastMsg;
        db = RentalSystemDatabase.getDatabase(PlaceHoldActivity.this);
        List<User> list = db.getRentalSystemDOA().getUserByUsername(username);
        if (list.size() == 1) {
            User user = list.get(0);
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
            else { numOfAttempts(); }
        }
        else { numOfAttempts(); }
        return false;
    }

    public void logTransaction(String username, String title, double price) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = new Date();
        String message = username + " placed hold for " + title + " and costs $" + String.format("%,.2f", price
                * ((returnDay + 1) - pickupDay)) + " (" + pickupDate + " - " + returnDate + "): " + formatter.format(date);
        Transaction_ transaction = new Transaction_("Place hold", message);
        db.getRentalSystemDOA().insert(transaction);
    }

    public void numOfAttempts() {
        String toastMsg;
        numOfAttempts--;
        toastMsg = "\"Username and/or password requirements not met!";
        Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();

        if (numOfAttempts == 0) {
            toastMsg = "Too many failed attempts! Returning to main menu";
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
    }

    public void menu() {
        Intent main = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main);
    }
}