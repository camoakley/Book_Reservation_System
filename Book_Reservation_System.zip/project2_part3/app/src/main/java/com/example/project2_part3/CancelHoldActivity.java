package com.example.project2_part3;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CancelHoldActivity extends AppCompatActivity {
    private EditText usernameText, passwordText, bookTitleText;
    private Button signInButton, cancelHoldButton;
    private RentalSystemDatabase db;
    private boolean validSignIn = false;
    private int numOfAttempts = 2;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_hold);

        usernameText = findViewById(R.id.usernameEditText);
        passwordText = findViewById(R.id.passwordEditText);
        bookTitleText = findViewById(R.id.bookTitleEditText);
        signInButton = findViewById(R.id.signInButton);
        cancelHoldButton = findViewById(R.id.cancelHoldButton);

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameText.getText().toString();
                String password = passwordText.getText().toString();
                String toastMsg;
                if (!usernameText.getText().toString().equals("") &&
                        (!passwordText.getText().toString().equals(""))) {
                    if (authenticateUser(username, password)) {
                        validSignIn = true;
                        toastMsg = "Sign in successful!";
                        Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_SHORT).show();
                        displayHeldBooks(username);
                    }
                }
            }
        });

        cancelHoldButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = bookTitleText.getText().toString();
                String username = usernameText.getText().toString();
                String toastMsg;
                if(!bookTitleText.getText().toString().equals("")) {
                    if(validSignIn == true) {
                        if (cancelHold(username, title)) {
                            toastMsg = "Hold has been successfully cancelled!";
                            Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                            logTransaction(username, title);
                            menu();
                        }
                    }
                    else {
                        toastMsg = "Please sign in before continuing!";
                        Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    /*

    public void placeHold(String title, int pickupDay, int returnDay) {
        db = RentalSystemDatabase.getDatabase(PlaceHoldActivity.this);
        List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(title);
        if (bookList.size() == 1) {
            validBook = true;
            ArrayList<String> tempAL = bookList.get(0).getAvailability();
            for(int i = pickupDay; i <= returnDay; i++)
                tempAL.set(i, "-");
            bookList.get(0).setAvailability(tempAL);
        }
        else {
            String toastMsg = "No matches found! Please enter a valid book title...";
            Toast.makeText(PlaceHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
        }
    }*/

    public boolean authenticateUser(String username, String password) {
        String toastMsg;
        db = RentalSystemDatabase.getDatabase(CancelHoldActivity.this);
        List<User> list = db.getRentalSystemDOA().getUserByUsername(username);
        if (list.size() == 1) {
            User user = list.get(0);
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
            else {
                numOfAttempts();
            }
        }
        else {
            numOfAttempts();
        }
        return false;
    }

    public void displayHeldBooks(String username) {
        db = RentalSystemDatabase.getDatabase(CancelHoldActivity.this);
        List<Reservation> reservationList = db.getRentalSystemDOA().getHeldBookByUserAndActive(username, true);
        if (reservationList.size() == 0) {
            String toastMsg = "No books are currently being held by this account!";
            Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
        else {
            String bookListText = "========== Held Book(s) ==========";
            for (Reservation reservation: reservationList) {
                bookListText += "\n" + reservation.getId() + ", Title: "
                        + reservation.getBookTitle() + ", Pickup: "
                        + reservation.getPickupDate() + ", Return: "
                        + reservation.getReturnDate();
            }
            String toastMsg;
            Toast.makeText(CancelHoldActivity.this, bookListText, Toast.LENGTH_LONG).show();
        }

    }

    public boolean cancelHold(String username, String title) {
        List<Book> bookList = db.getRentalSystemDOA().getBookByTitle(title);
        if (bookList.size() == 0) {
            String toastMsg = "There are no existing books with that title!";
            Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
        }
        else {
            List<Reservation> reservationList = db.getRentalSystemDOA().getHeldBookByUserAndActive(username, true);

            boolean flag = false;
            String toastMsg;
            for (Reservation reservation : reservationList) {
                for (Book book : bookList) {
                    if (reservation.getBookTitle().equals(book.getTitle())) {
                        flag = true;
                        String availability = book.getAvailability();
                        for (int i = reservation.getPickupDay(); i <= reservation.getReturnDay(); i++) {
                            availability = availability.substring(0, i) + "+" + availability.substring(i + 1);
                        }
                        book.setAvailability(availability);
                        db.getRentalSystemDOA().update(book);
                        reservation.setActive(false);
                        db.getRentalSystemDOA().update(reservation);
                        return true;
                    }
                }
            }
            if (flag == false) {
                toastMsg = "This book is not currently reserved!";
                Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
                menu();
                return false;
            }
        }
        return false;
    }

    public void logTransaction(String username, String title) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        Date date = new Date();
        db = RentalSystemDatabase.getDatabase(CancelHoldActivity.this);
        List<Reservation> reservationList = db.getRentalSystemDOA().getHeldBookByUserAndTitle(username, title);
        if (reservationList.size() > 0) {
            String message = username + " canceled hold for " + title + " (" + reservationList.get(0).getPickupDate()
                    + " - " + reservationList.get(0).getReturnDate() + ") : " + formatter.format(date);
            Transaction_ transaction = new Transaction_("Cancel hold", message);
            db.getRentalSystemDOA().insert(transaction);
        }
    }

    public void numOfAttempts() {
        String toastMsg;
        numOfAttempts--;
        toastMsg = "\"Username and/or password requirements not met!";
        Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();

        if (numOfAttempts == 0) {
            toastMsg = "Too many failed attempts! Returning to main menu";
            Toast.makeText(CancelHoldActivity.this, toastMsg, Toast.LENGTH_LONG).show();
            menu();
        }
    }

    public void menu() {
        Intent main = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(main);
    }
}