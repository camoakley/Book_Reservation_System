package com.example.project2_part3;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


@Entity(tableName = "Book")
public class Book {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String author;
    private String title;
    private double price;
    private String availability;

    public Book ()
    {
        // default constructor - no initialization.
    }

    public Book (String title, String author, double price)
    {
        this.author = author;
        this.title = title;
        this.price = price;
        this.availability =  "-+++++++++++++++++++++++++++++++";

    }


    // MUTATORS
    public int getId() {
        return id;
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public String getAvailability() { return availability; }

    public void setId(int id) {
        this.id = id;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setAvailability(String availability) { this.availability = availability; }
}

