package com.example.project2_part3;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Transaction_")
public class Transaction_ {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String type;
    private String message;

    public Transaction_ () {
        // default constructor - no initialization.
    }

    public Transaction_ (String type, String message) {
        this.type = type;
        this.message = message;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getMessage() {
        return message;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
